import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { readFile } from 'node:fs/promises';
import { randomBytes, randomUUID, createHash, timingSafeEqual } from 'node:crypto';
import { openAppStore } from './lib/app-store.mjs';
import { dateKey, monday, buildPlan, localInstant, makeDigest } from './lib/planner.mjs';
import { createMicrosoft, syncAccount, parseCalendar, fetchCalendar, sendDaily } from './lib/integrations.mjs';
import {validPasswordHash,verifyPassword,makePasswordHash} from './lib/auth.mjs';

const ROOT=path.dirname(fileURLToPath(import.meta.url));
const production=process.env.APP_ENV==='production';
const port=Number(process.env.PORT||4317),host=process.env.HOST||(production?'0.0.0.0':'127.0.0.1');
const baseUrl=(process.env.BASE_URL||`http://localhost:${port}`).replace(/\/$/,'');
const allowed=(process.env.ALLOWED_EMAILS||'').split(',').map(v=>v.trim().toLowerCase()).filter(Boolean);
const key=process.env.ENCRYPTION_KEY||'';
const clientId=process.env.MICROSOFT_CLIENT_ID||'',clientSecret=process.env.MICROSOFT_CLIENT_SECRET||'';
let passwordHash=process.env.OWNER_PASSWORD_HASH||'';
const setupHash=process.env.OWNER_SETUP_TOKEN_HASH||'';
if(key&&!/^[a-f0-9]{64}$/i.test(key)) throw new Error('ENCRYPTION_KEY must be 64 hexadecimal characters.');
if(passwordHash&&!validPasswordHash(passwordHash))throw new Error('OWNER_PASSWORD_HASH is invalid. Generate it with scripts/set-password.mjs.');
if(setupHash&&!/^[a-f0-9]{64}$/i.test(setupHash))throw new Error('OWNER_SETUP_TOKEN_HASH must be a SHA-256 digest.');
if((clientId||clientSecret)&&(!clientId||!clientSecret||!key||!allowed.length)) throw new Error('Microsoft sign-in requires MICROSOFT_CLIENT_ID, MICROSOFT_CLIENT_SECRET, ALLOWED_EMAILS and a persistent ENCRYPTION_KEY.');
if(production&&(!key||(!passwordHash&&!clientId&&!setupHash)))throw new Error('Production sign-in requires an owner password hash, a private setup token digest or Microsoft configuration, plus a persistent ENCRYPTION_KEY.');
if(production&&!baseUrl.startsWith('https://')) throw new Error('Production requires an HTTPS BASE_URL.');
if(!production&&!['127.0.0.1','localhost','::1'].includes(host)) throw new Error('Development preview must bind to loopback.');
const store=await openAppStore({directory:path.resolve(ROOT,process.env.DATA_DIR||'data'),key,databaseUrl:process.env.DATABASE_URL,requireDatabase:process.env.REQUIRE_DATABASE==='true'});
if(!passwordHash){const owner=await store.get('auth:owner');if(owner){if(!validPasswordHash(owner.hash))throw new Error('Saved owner sign-in needs attention.');passwordHash=owner.hash;}}
const microsoft=await createMicrosoft({clientId,clientSecret,baseUrl,emailEnabled:process.env.ENABLE_DAILY_EMAIL==='true'},store.secrets);
const authRequired=production||!!microsoft||!!passwordHash||!!setupHash;
const backgroundSyncEnabled=process.env.ENABLE_BACKGROUND_SYNC!=='false';
const hash=value=>createHash('sha256').update(value).digest('hex');
const cookie=(name,value,maxAge=604800)=>`${name}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${production?'; Secure':''}`;
const error=(status,message)=>Object.assign(new Error(message),{status});
const text=(value,max=500)=>typeof value==='string'?value.trim().slice(0,max):'';
const validDate=d=>typeof d==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(d)&&!Number.isNaN(Date.parse(d))&&new Date(d).toISOString().slice(0,10)===d;
const safeUrl=v=>{v=text(v,3000);if(!v)return '';try{const u=new URL(v);if(!['https:','http:'].includes(u.protocol)||u.username||u.password) throw Error();return u.href;}catch{throw error(400,'Use a complete http or https link.');}};
const requiredDescription=v=>{const value=text(v,6000);if(!value)throw error(400,'A criterion statement is required.');return value;};
const requiredTitle=v=>{const title=text(v,200);if(!title)throw error(400,'A title is required.');return title;};
const number=(v,min,max)=>{const n=Number(v);if(!Number.isFinite(n)||n<min||n>max)throw error(400,`Enter a number between ${min} and ${max}.`);return n;};
const time=v=>{if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(v||''))throw error(400,'Use a valid time.');return v;};
function validateTask(b,id=randomUUID()) {return {id,title:requiredTitle(b.title),category:['work','university','ksb'].includes(b.category)?b.category:'university',remainingHours:number(b.remainingHours,0,500),dueDate:b.dueDate?(validDate(b.dueDate)?b.dueDate:(()=>{throw error(400,'Use a valid deadline date.');})()):'',dueTime:b.dueTime?time(b.dueTime):'',priority:number(b.priority||2,1,3),status:b.status==='done'?'done':'active',notes:text(b.notes,5000),sourceUrl:safeUrl(b.sourceUrl),availableFrom:b.availableFrom?(validDate(b.availableFrom)?b.availableFrom:''):''};}
const halfHours=(value,max=500)=>{const n=number(value,.5,max);if(!Number.isInteger(n*2))throw error(400,'Use half-hour increments.');return n;};
function validateDaily(entry,tasks) {
  if(!validDate(entry.date))throw error(400,'Choose a valid planning date.');
  const hours=number(entry.hours,0,12);if(!Number.isInteger(hours*2))throw error(400,'Use half-hour increments.');
  const startTime=time(entry.startTime),endTime=time(entry.endTime);if(startTime>=endTime)throw error(400,'Finish time must follow start time.');
  if(!Array.isArray(entry.items)||entry.items.length>100)throw error(400,'Choose up to 100 tasks.');
  const seen=new Set(),items=entry.items.map(item=>{const taskId=text(item.taskId,100);if(!tasks.some(t=>t.id===taskId))throw error(400,'A selected task no longer exists. Refresh your workload.');if(seen.has(taskId))throw error(400,'Include each task only once in your daily ranking.');seen.add(taskId);return {taskId,hours:halfHours(item.hours)};});
  return {date:entry.date,hours,startTime,endTime,fillFromBacklog:!!entry.fillFromBacklog,items,savedAt:new Date().toISOString()};
}
function validateScope(b){if(!validDate(b.date))throw error(400,'Choose a valid scope date.');return {date:b.date,outcome:text(b.outcome,1000),mustDo:text(b.mustDo,4000),notToday:text(b.notToday,4000),notes:text(b.notes,4000),savedAt:new Date().toISOString()};}
async function body(req) {let size=0,chunks=[];for await(const chunk of req){size+=chunk.length;if(size>3*1024*1024)throw error(413,'This request is too large.');chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString()||'{}');}catch{throw error(400,'Invalid JSON.');}}
function headers(res) {res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self' https://login.microsoftonline.com");res.setHeader('Cache-Control','no-store');if(production)res.setHeader('Strict-Transport-Security','max-age=31536000');}
function json(res,value,status=200) {res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(value));}
function redirect(res,url,cookies=[]) {res.writeHead(302,{Location:url,...(cookies.length?{'Set-Cookie':cookies}:{})});res.end();}
let running=false,loginBusy=false;
async function getPlan(s,demo=false,access=store) {
  const today=dateKey();
  const signature=hash(JSON.stringify({today,tasks:s.tasks,dailyEntries:s.dailyEntries||[],events:[...s.events].sort((a,b)=>a.id.localeCompare(b.id)),reviews:s.reviews,hours:s.settings.hours,startTime:s.settings.startTime,endTime:s.settings.endTime}));
  const cacheKey=demo?'plan:demo':'plan:real',cached=await access.get(cacheKey);
  if(cached?.signature===signature)return cached.plan;
  const plan=buildPlan(s);await access.set(cacheKey,{signature,plan});return plan;
}
async function runAgent() {
  if(running)return;running=true;
  try {
    const issues=[];
    for(const account of (await store.read()).accounts) {
      try {
        const result=await syncAccount(microsoft,account,(await store.read()));
        await store.mutate(async s=>{const a=s.accounts.find(a=>a.id===account.id&&a.role===account.role);if(!a)return;s.events=s.events.filter(e=>e.source!==account.role).concat(result.events);for(const m of result.messages){const old=s.inbox.find(x=>x.id===m.id);if(old)Object.assign(old,m);else s.inbox.push({...m,status:m.needsReview?'review':'information'});}a.lastSync=result.lastSync;a.error=null;});
      } catch(e) {const msg=text(e.message,250);issues.push(`${account.role}: ${msg}`);await store.mutate(async s=>{const a=s.accounts.find(a=>a.id===account.id);if(a)a.error=msg;});}
    }
    for(const feed of (await store.read()).feeds) {
      try {const url=await store.secrets.get('feed:'+feed.id);if(!url)continue;const events=parseCalendar(await fetchCalendar(url),{source:feed.id});await store.mutate(async s=>{const f=s.feeds.find(f=>f.id===feed.id);if(!f)return;s.events=s.events.filter(e=>e.source!==feed.id).concat(events);f.lastSync=new Date().toISOString();f.error=null;f.count=events.length;});}
      catch(e){const msg=text(e.message,250);issues.push(`Calendar: ${msg}`);await store.mutate(async s=>{const f=s.feeds.find(f=>f.id===feed.id);if(f)f.error=msg;});}
    }
    let s=(await store.read());const day=dateKey(),clock=new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/London',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(new Date());
    const university=s.accounts.find(a=>a.role==='university');
    if(microsoft&&process.env.ENABLE_DAILY_EMAIL==='true'&&s.settings.dailyEmail&&university&&clock>=s.settings.dailyTime&&s.settings.lastDigest!==day) {
      try{await sendDaily(microsoft,university,s,await getPlan(s),baseUrl);await store.mutate(async s=>{s.settings.lastDigest=day;s.settings.digestError=null;});}
      catch(e){issues.push('Daily briefing could not be delivered. Reconnect your university account.');await store.mutate(async s=>{s.settings.digestError='Delivery failed. Check your connection and Mail.Send permission.';});}
    }
    await store.mutate(async s=>{s.agent={lastRun:new Date().toISOString(),error:issues.join(' ')||null};});await store.prune();
  } finally {running=false;}
}

const server=http.createServer(async(req,res)=>{
  headers(res);
  try {
    const requestHost=req.headers.host||'';
    const permittedHosts=[new URL(baseUrl).host,...(!production?[`localhost:${port}`,`127.0.0.1:${port}`]:[])];
    if(!permittedHosts.includes(requestHost))throw error(400,'Unrecognised host.');
    const url=new URL(req.url,baseUrl),p=url.pathname;
    const cookies=Object.fromEntries((req.headers.cookie||'').split(';').map(v=>v.trim().split('=')));
    const session=cookies.ahead_session?await store.get('session:'+hash(cookies.ahead_session)):null;
    const signedIn=!!session&&session.expires>Date.now()&&(session.auth==='password'?!!passwordHash&&session.version===hash(passwordHash):!!microsoft&&allowed.includes((session.email||'').toLowerCase()));
    const demo=cookies.ahead_demo==='1';
    const protectedRoute=p.startsWith('/api/')&&!['/api/status','/api/login','/api/setup'].includes(p);
    if(authRequired&&!signedIn&&protectedRoute)throw error(401,'Sign in to open your private workspace.');
    if(!['GET','HEAD'].includes(req.method)) {
      if(req.headers['x-ahead-request']!=='1')throw error(403,'Request verification failed.');
      const origin=req.headers.origin;
      if(!origin||!permittedHosts.map(h=>`${production?'https':'http'}://${h}`).includes(origin))throw error(403,'Request origin was rejected.');
    }
    if(p==='/healthz')return json(res,{ok:true});
    if(p==='/api/status')return json(res,{signedIn:!authRequired||signedIn,authRequired,setupRequired:!!setupHash&&!passwordHash&&!microsoft,passwordEnabled:!!passwordHash,microsoftConfigured:!!microsoft,local:!production,backgroundSyncEnabled,emailEnabled:process.env.ENABLE_DAILY_EMAIL==='true',user:session?.email||''});
    if(p==='/api/setup'&&req.method==='POST'){
      if(!setupHash||passwordHash||microsoft)throw error(409,'This planner is already configured. Sign in with your passphrase.');
      const b=await body(req);
      if(typeof b.token!=='string'||b.token.length>128||!timingSafeEqual(Buffer.from(hash(b.token),'hex'),Buffer.from(setupHash,'hex')))throw error(403,'Open the private setup link supplied for this planner.');
      const created=await makePasswordHash(b.password).catch(()=>{throw error(400,'Choose a passphrase of 14 to 1,024 characters.');});
      if(!await store.setIfAbsent('auth:owner',{hash:created,createdAt:new Date().toISOString()}))throw error(409,'This planner has already been claimed. Sign in instead.');
      passwordHash=created;
      const token=randomBytes(32).toString('base64url');await store.set('session:'+hash(token),{email:'Owner',auth:'password',version:hash(passwordHash),expires:Date.now()+7*86400000});
      res.setHeader('Set-Cookie',cookie('ahead_session',token));return json(res,{ok:true});
    }
    if(p==='/api/login'&&req.method==='POST'){
      if(!passwordHash)throw error(400,'Passphrase sign-in is not configured.');
      const b=await body(req);if(typeof b.password!=='string'||b.password.length>1024)throw error(400,'Enter your passphrase.');
      if(loginBusy)throw error(429,'A sign-in attempt is already running. Try again shortly.');
      loginBusy=true;
      try{
      const now=Date.now(),attempts=await store.get('auth:attempts');
      const record=attempts&&now-attempts.since<15*60000?attempts:{since:now,count:0};
      if(record.count>=10)throw error(429,'Too many sign-in attempts. Try again after 15 minutes.');
      record.count++;await store.set('auth:attempts',record);
        if(!await verifyPassword(b.password,passwordHash))throw error(401,'Incorrect passphrase.');
        await store.delete('auth:attempts');if(cookies.ahead_session)await store.delete('session:'+hash(cookies.ahead_session));
        const token=randomBytes(32).toString('base64url');await store.set('session:'+hash(token),{email:'Owner',auth:'password',version:hash(passwordHash),expires:Date.now()+7*86400000});res.setHeader('Set-Cookie',cookie('ahead_session',token));return json(res,{ok:true});
      }finally{loginBusy=false;}
    }
    if(p==='/auth/start') {
      if(!microsoft) return redirect(res,'/?setup=microsoft');
      const role=['work','university'].includes(url.searchParams.get('role'))?url.searchParams.get('role'):'login';
      if(role!=='login'&&authRequired&&!signedIn)throw error(401,'Sign in before connecting another account.');
      const flow=await microsoft.begin(role),nonce=randomBytes(32).toString('base64url');
      await store.set('oauth:'+hash(nonce),{...flow,expires:Date.now()+600000});
      return redirect(res,flow.url,[cookie('ahead_oauth',nonce,600)]);
    }
    if(p==='/auth/callback') {
      const flowKey='oauth:'+hash(cookies.ahead_oauth||''),flow=await store.get(flowKey);await store.delete(flowKey);
      if(!flow||flow.expires<Date.now()||flow.state!==url.searchParams.get('state'))throw error(403,'Sign-in expired or failed verification. Start again.');
      if(url.searchParams.has('error'))return redirect(res,'/?auth=denied',[cookie('ahead_oauth','',0)]);
      const result=await microsoft.finish(flow,url.searchParams.get('code'));
      const profile=await microsoft.profile(result.accessToken),email=(profile.mail||profile.userPrincipalName||'').toLowerCase();
      if(!allowed.includes(email)){await microsoft.remove(result.account.homeAccountId);throw error(403,'This account is not on the owner allowlist.');}
      if(flow.role!=='login')await store.mutate(async s=>{s.accounts=s.accounts.filter(a=>a.role!==flow.role);s.accounts.push({id:result.account.homeAccountId,email,role:flow.role,lastSync:null,error:null});});
      const token=randomBytes(32).toString('base64url');await store.set('session:'+hash(token),{email,auth:'microsoft',expires:Date.now()+7*86400000});
      if(flow.role!=='login')setTimeout(()=>runAgent().catch(()=>{}),100);
      return redirect(res,'/',[cookie('ahead_session',token),cookie('ahead_oauth','',0)]);
    }
    if(p==='/api/logout'&&req.method==='POST'){if(cookies.ahead_session)await store.delete('session:'+hash(cookies.ahead_session));res.setHeader('Set-Cookie',cookie('ahead_session','',0));return json(res,{ok:true});}
    if(p==='/api/bootstrap'&&req.method==='GET') {
      const s=(await store.read(demo));return json(res,{state:s,plan:await getPlan(s,demo),today:dateKey(),demo,microsoftConfigured:!!microsoft,backgroundSyncEnabled,emailEnabled:process.env.ENABLE_DAILY_EMAIL==='true',local:!production});
    }
    if(p==='/api/demo'&&req.method==='POST'){const b=await body(req);res.setHeader('Set-Cookie',cookie('ahead_demo',b.enabled?'1':'',b.enabled?86400:0));if(b.enabled&&!await store.get('demo'))await store.mutate(()=>{},true);return json(res,{ok:true});}
    if(p==='/api/tasks'&&req.method==='POST') {
      const b=await body(req),id=text(b.id,100)||randomUUID(),task=validateTask(b,id);
      await store.mutate(async s=>{const old=s.tasks.find(t=>t.id===id);if(old)Object.assign(old,task);else s.tasks.push(task);},demo);return json(res,{ok:true,id});
    }
    if(p==='/api/task/delete'&&req.method==='POST'){const b=await body(req);await store.mutate(async s=>{s.tasks=s.tasks.filter(t=>t.id!==b.id);for(const d of s.dailyEntries)d.items=d.items.filter(i=>i.taskId!==b.id);},demo);return json(res,{ok:true});}
    if(p==='/api/session/complete'&&req.method==='POST') {
      const b=await body(req);const hours=number(b.hours,.5,1.5);
      await store.mutate(async (s,tx)=>{const t=s.tasks.find(t=>t.id===b.taskId);if(!t)throw error(404,'Task not found.');const block=(await getPlan(s,demo,tx)).days[0].sessions.find(x=>x.taskId===b.taskId&&x.start===b.start&&x.hours===hours);if(!block)throw error(409,'This block has changed or was already completed. Refresh your plan.');t.remainingHours=Math.max(0,Number(t.remainingHours)-hours);if(!t.remainingHours)t.status='done';s.events.push({id:randomUUID(),title:t.title,start:block.start,end:block.end,source:'focus-completed',busy:true,completed:true,taskId:t.id});},demo);return json(res,{ok:true});
    }
    if(p==='/api/daily-entry'&&req.method==='POST') {
      const b=await body(req);
      if(!Array.isArray(b.items)||b.items.length>100||b.items.some(i=>!i||typeof i!=='object'))throw error(400,'Choose up to 100 tasks.');
      await store.mutate(async s=>{
        const newTasks=[];const items=b.items.map(item=>{
          if(item.taskId)return item;
          const hours=halfHours(item.hours);const task=validateTask({...item,remainingHours:hours,status:'active',availableFrom:b.date});newTasks.push(task);return {taskId:task.id,hours};
        });
        const entry=validateDaily({...b,items},s.tasks.concat(newTasks));
        s.tasks.push(...newTasks);s.dailyEntries=s.dailyEntries.filter(d=>d.date!==entry.date).concat(entry);
      },demo);return json(res,{ok:true});
    }
    if(p==='/api/daily-entry/clear'&&req.method==='POST') {const b=await body(req);if(!validDate(b.date))throw error(400,'Choose a valid date.');await store.mutate(async s=>{s.dailyEntries=s.dailyEntries.filter(d=>d.date!==b.date);},demo);return json(res,{ok:true});}
    if(p==='/api/daily-scope'&&req.method==='POST') {const b=validateScope(await body(req));await store.mutate(async s=>{s.dailyScopes=s.dailyScopes.filter(d=>d.date!==b.date).concat(b);},demo);return json(res,{ok:true});}
    if(p==='/api/review'&&req.method==='POST') {
      const b=await body(req);if(!validDate(b.week)||monday(b.week)!==b.week)throw error(400,'Choose the Monday of your planning week.');
      if(!Array.isArray(b.hours)||b.hours.length!==7)throw error(400,'Enter seven daily focus budgets.');
      const hours=b.hours.map(h=>number(h,0,12)),tasks=(b.tasks||[]).filter(t=>t.title?.trim()).map(t=>validateTask({...t,availableFrom:b.week}));
      await store.mutate(async s=>{s.reviews=s.reviews.filter(r=>r.week!==b.week);s.reviews.push({week:b.week,hours,notes:text(b.notes,4000),savedAt:new Date().toISOString()});s.tasks.push(...tasks);},demo);return json(res,{ok:true});
    }
    if(p==='/api/ksbs'&&req.method==='POST') {
      const b=await body(req),id=text(b.id,100)||randomUUID();
      const record={id,code:requiredTitle(b.code),description:requiredDescription(b.description),kind:['Knowledge','Skill','Behaviour'].includes(b.kind)?b.kind:'Knowledge',status:['Evidence needed','Evidence drafted','Submitted','Accepted'].includes(b.status)?b.status:'Evidence needed',nextAction:text(b.nextAction,1000)};
      await store.mutate(async s=>{const old=s.ksbs.find(k=>k.id===id);if(old)Object.assign(old,record);else s.ksbs.push(record);},demo);return json(res,{ok:true});
    }
    if(p==='/api/ksb/delete'&&req.method==='POST') {const b=await body(req);await store.mutate(async s=>{s.ksbs=s.ksbs.filter(k=>k.id!==b.id);for(const e of s.evidence)e.ksbIds=e.ksbIds.filter(id=>id!==b.id);},demo);return json(res,{ok:true});}
    if(p==='/api/ksbs/import'&&req.method==='POST') {
      const b=await body(req);if(!Array.isArray(b.rows)||b.rows.length>1000)throw error(400,'Import up to 1,000 KSB rows.');
      const records=b.rows.map(k=>({id:randomUUID(),code:requiredTitle(k.code),description:requiredDescription(k.description),kind:['Knowledge','Skill','Behaviour'].includes(k.kind)?k.kind:'Knowledge',status:'Evidence needed',nextAction:''}));
      let count=0;await store.mutate(async s=>{for(const k of records)if(!s.ksbs.some(x=>x.code.toLowerCase()===k.code.toLowerCase())){s.ksbs.push(k);count++;}},demo);return json(res,{ok:true,count});
    }
    if(p==='/api/evidence'&&req.method==='POST') {
      const b=await body(req),id=text(b.id,100)||randomUUID();
      const record={id,title:requiredTitle(b.title),date:validDate(b.date)?b.date:dateKey(),notes:text(b.notes,6000),url:safeUrl(b.url),hours:number(b.hours||0,0,500),ksbIds:Array.isArray(b.ksbIds)?b.ksbIds.slice(0,100).map(v=>text(v,100)):[],status:['Draft','Submitted','Accepted'].includes(b.status)?b.status:'Draft'};
      await store.mutate(async s=>{record.ksbIds=record.ksbIds.filter(id=>s.ksbs.some(k=>k.id===id));const old=s.evidence.find(e=>e.id===id);if(old)Object.assign(old,record);else s.evidence.push(record);},demo);return json(res,{ok:true});
    }
    if(p==='/api/evidence/delete'&&req.method==='POST'){const b=await body(req);await store.mutate(async s=>{s.evidence=s.evidence.filter(e=>e.id!==b.id);},demo);return json(res,{ok:true});}
    if(p==='/api/inbox'&&req.method==='POST') {
      const b=await body(req);await store.mutate(async s=>{const m=s.inbox.find(m=>m.id===b.id);if(!m)throw error(404,'Message not found.');m.status=['review','resolved','information'].includes(b.status)?b.status:'review';if(b.task){const t=validateTask(b.task);s.tasks.push(t);m.taskId=t.id;m.status='resolved';}},demo);return json(res,{ok:true});
    }
    if(p==='/api/events'&&req.method==='POST') {
      const b=await body(req);if(!validDate(b.date))throw error(400,'Choose a valid date.');const start=localInstant(b.date,time(b.start)),end=localInstant(b.date,time(b.end));if(+end<=+start)throw error(400,'End time must follow start time.');
      await store.mutate(async s=>s.events.push({id:randomUUID(),title:requiredTitle(b.title),start:start.toISOString(),end:end.toISOString(),source:'manual',busy:true,external:false}),demo);return json(res,{ok:true});
    }
    if(p==='/api/event/delete'&&req.method==='POST'){const b=await body(req);await store.mutate(async s=>{s.events=s.events.filter(e=>e.id!==b.id||e.external);},demo);return json(res,{ok:true});}
    if(p==='/api/calendar/import'&&req.method==='POST') {
      const b=await body(req),name=requiredTitle(b.name),events=parseCalendar(text(b.ics,2*1024*1024),{source:`import:${name}`});
      await store.mutate(async s=>{s.events=s.events.filter(e=>e.source!==`import:${name}`).concat(events);},demo);return json(res,{ok:true,count:events.length});
    }
    if(p==='/api/feed'&&req.method==='POST') {
      if(demo)throw error(400,'Leave example mode to connect a real calendar.');
      const b=await body(req),id=randomUUID(),name=requiredTitle(b.name),feedUrl=safeUrl(b.url);
      const events=parseCalendar(await fetchCalendar(feedUrl),{source:id});await store.secrets.set('feed:'+id,feedUrl);
      await store.mutate(async s=>{s.feeds.push({id,name,lastSync:new Date().toISOString(),count:events.length,error:null});s.events.push(...events);});return json(res,{ok:true,count:events.length});
    }
    if(p==='/api/disconnect'&&req.method==='POST') {
      if(demo)throw error(400,'Leave example mode first.');const b=await body(req),s=(await store.read()),account=s.accounts.find(a=>a.role===b.role);
      if(account){await store.mutate(async s=>{s.accounts=s.accounts.filter(a=>a.role!==b.role);s.events=s.events.filter(e=>e.source!==b.role);});if(!s.accounts.some(a=>a.id===account.id&&a.role!==b.role))await microsoft.remove(account.id);}
      if(b.feedId){await store.secrets.delete('feed:'+b.feedId);await store.mutate(async s=>{s.feeds=s.feeds.filter(f=>f.id!==b.feedId);s.events=s.events.filter(e=>e.source!==b.feedId);});}return json(res,{ok:true});
    }
    if(p==='/api/settings'&&req.method==='POST') {
      const b=await body(req),startTime=time(b.startTime),endTime=time(b.endTime),dailyTime=time(b.dailyTime);if(startTime>=endTime)throw error(400,'Focus window end must follow the start.');
      if(b.dailyEmail&&!demo&&(process.env.ENABLE_DAILY_EMAIL!=='true'||!(await store.read()).accounts.some(a=>a.role==='university')))throw error(400,'Enable daily email on the server and connect your university account first.');
      await store.mutate(async s=>Object.assign(s.settings,{startTime,endTime,dailyTime,dailyEmail:!!b.dailyEmail}),demo);return json(res,{ok:true});
    }
    if(p==='/api/sync'&&req.method==='POST'){if(demo)throw error(400,'Example data has no live connections.');if(running)return json(res,{ok:true,running:true});runAgent().catch(()=>{});return json(res,{ok:true,running:true});}
    if(p==='/api/backup'&&req.method==='GET') {const s=(await store.read(demo));res.setHeader('Content-Disposition','attachment; filename="ahead-backup.json"');return json(res,{schema:1,exportedAt:new Date().toISOString(),tasks:s.tasks,ksbs:s.ksbs,evidence:s.evidence,reviews:s.reviews,dailyEntries:s.dailyEntries,dailyScopes:s.dailyScopes,events:s.events.filter(e=>e.source==='manual'),settings:{...s.settings,lastDigest:undefined}});}
    if(p==='/api/restore'&&req.method==='POST') {
      const b=await body(req);if(b.schema!==1||!['tasks','ksbs','evidence','reviews','events'].every(k=>Array.isArray(b[k])&&b[k].length<=10000))throw error(400,'Choose a valid Ahead backup.');
      // Only restore application data. Never restore accounts, sessions, secrets or subscription URLs.
      const tasks=b.tasks.map(t=>validateTask(t,text(t.id,100)||randomUUID()));
      if(![b.dailyEntries||[],b.dailyScopes||[]].every(a=>Array.isArray(a)&&a.length<=10000))throw error(400,'Invalid daily planning records.');
      const dailyEntries=(b.dailyEntries||[]).map(d=>validateDaily(d,tasks)),dailyScopes=(b.dailyScopes||[]).map(validateScope);
      const uniqueDates=rows=>new Set(rows.map(d=>d.date)).size===rows.length;if(!uniqueDates(dailyEntries)||!uniqueDates(dailyScopes))throw error(400,'Each date must have one daily entry and one scope record.');
      await store.mutate(async s=>{s.tasks=tasks;s.dailyEntries=dailyEntries;s.dailyScopes=dailyScopes;s.ksbs=b.ksbs.map(k=>({id:requiredTitle(k.id),code:requiredTitle(k.code),description:requiredDescription(k.description),kind:['Knowledge','Skill','Behaviour'].includes(k.kind)?k.kind:'Knowledge',status:['Evidence needed','Evidence drafted','Submitted','Accepted'].includes(k.status)?k.status:'Evidence needed',nextAction:text(k.nextAction,1000)}));s.evidence=b.evidence.map(e=>({id:requiredTitle(e.id),title:requiredTitle(e.title),date:validDate(e.date)?e.date:dateKey(),notes:text(e.notes,6000),url:safeUrl(e.url),hours:number(e.hours||0,0,500),ksbIds:(e.ksbIds||[]).filter(id=>s.ksbs.some(k=>k.id===id)),status:['Draft','Submitted','Accepted'].includes(e.status)?e.status:'Draft'}));s.reviews=b.reviews.filter(r=>validDate(r.week)&&monday(r.week)===r.week&&r.hours.length===7).map(r=>({week:r.week,hours:r.hours.map(h=>number(h,0,12)),notes:text(r.notes,4000),savedAt:text(r.savedAt)}));s.events=s.events.filter(e=>e.source!=='manual').concat(b.events.filter(e=>Number.isFinite(Date.parse(e.start))&&Number.isFinite(Date.parse(e.end))&&+new Date(e.end)>+new Date(e.start)).map(e=>({id:requiredTitle(e.id),title:requiredTitle(e.title),start:new Date(e.start).toISOString(),end:new Date(e.end).toISOString(),source:'manual',external:false,busy:true})));},demo);return json(res,{ok:true});
    }
    if(p==='/api/digest'&&req.method==='GET'){res.writeHead(200,{'Content-Type':'text/plain; charset=utf-8'});const s=(await store.read(demo));return res.end(makeDigest(s,await getPlan(s,demo)));}
    if(req.method!=='GET'&&req.method!=='HEAD')throw error(404,'This action was not found.');
    const files={'/':'index.html','/app.js':'app.js','/styles.css':'styles.css','/favicon.svg':'favicon.svg'};
    if(!files[p])throw error(404,'Page not found.');
    const content=await readFile(path.join(ROOT,'public',files[p]));res.writeHead(200,{'Content-Type':p.endsWith('.js')?'text/javascript; charset=utf-8':p.endsWith('.css')?'text/css; charset=utf-8':p.endsWith('.svg')?'image/svg+xml':'text/html; charset=utf-8'});res.end(req.method==='HEAD'?undefined:content);
  } catch(e) {if(!res.headersSent)json(res,{error:e.status?e.message:'Something went wrong. Please try again.'},e.status||500);else res.end();if(!e.status)console.error('Request failed:',e.name);}
});
server.listen(port,host,()=>console.log(`Ahead is ready at ${baseUrl} (${authRequired?'private sign-in required':'local preview; no real accounts connected'})`));
const worker=backgroundSyncEnabled?setInterval(()=>runAgent().catch(()=>{}),5*60000):null;worker?.unref();
if(authRequired&&backgroundSyncEnabled)setTimeout(()=>runAgent().catch(()=>{}),2000).unref();
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>{clearInterval(worker);server.close(async()=>{await store.close();process.exit(0);});setTimeout(()=>process.exit(0),5000).unref();});
