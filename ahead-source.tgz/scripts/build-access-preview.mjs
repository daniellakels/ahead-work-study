import {mkdir,readFile,writeFile,copyFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import vm from 'node:vm';
import {demoState} from '../lib/store.mjs';
import {buildPlan,dateKey} from '../lib/planner.mjs';

// Build only from the illustrative fixture. Never open the user's data directory.
export async function buildAccessPreview(output) {
  const root=fileURLToPath(new URL('..',import.meta.url));
  output=output||path.join(root,'access-preview');
  await mkdir(output,{recursive:true});
  const source=(await readFile(path.join(root,'public/app.js'),'utf8')).replace('start();setInterval(','setInterval(');
  const app={innerHTML:''},context=vm.createContext({
    document:{querySelector:selector=>selector==='#app'?app:null,addEventListener:()=>{}},
    console,Intl,Date,URLSearchParams,location:{search:'',hash:''},setInterval:()=>{},setTimeout:()=>{},clearTimeout:()=>{}
  });
  vm.runInContext(source,context);
  const state=demoState();
  context.fixture={state,plan:buildPlan(state),today:dateKey(),demo:true,microsoftConfigured:false,emailEnabled:false,local:false};
  vm.runInContext('data=fixture;status={authRequired:false};',context);
  const pages={};
  for(const page of ['today','daily','scope','week','tasks','ksbs','inbox','review','connections']) {
    context.previewPage=page;
    vm.runInContext('page=previewPage;render();',context);
    pages[page]=app.innerHTML.replace('These are illustrative tasks and KSBs. Your real workspace is separate.','Work-laptop access test: sample data only. Browse the pages; saving, sign-in and account connections are disabled.');
  }
  const script=`const pages=${JSON.stringify(pages)};
function render(){
  const page=location.hash.slice(1),app=document.querySelector('#app');
  app.innerHTML=pages[page]||pages.today;
  app.querySelector('[data-action="menu"].icon-button')?.classList.add('mobile-menu');
  for(const el of app.querySelectorAll('input,textarea,select,button')){
    if(el.matches('button[data-action="nav"],button[data-action="menu"]'))continue;
    el.disabled=true;el.title='Access preview only: changes are disabled.';
  }
  document.querySelector('#access-status').textContent='Preview ready: page styles and JavaScript loaded. Sample data only.';
}
document.addEventListener('click',event=>{
  const target=event.target.closest('[data-action],a');if(!target)return;
  const action=target.dataset.action;
  if(action==='nav'){event.preventDefault();location.hash=target.dataset.page||'today';render();window.scrollTo(0,0);return;}
  if(action==='menu'){event.preventDefault();document.querySelector('.layout').classList.toggle('menu-open');return;}
  if(target.matches('a[href="#main"]'))return;
  event.preventDefault();if(target.matches('a.brand')){location.hash='today';render();}
});
document.addEventListener('submit',event=>event.preventDefault());
window.addEventListener('hashchange',render);render();
`;
  const html=(await readFile(path.join(root,'public/index.html'),'utf8'))
    .replace('Ahead · Work, study, in balance','Ahead · Free work-laptop access test')
    .replace('src="/app.js"','src="/preview.js"')
    .replace('<body>','<body>\n  <p id="access-status" class="access-status" role="status">Loading the access test… If this message stays here, scripts may be blocked.</p>');
  await writeFile(path.join(output,'index.html'),html);
  await writeFile(path.join(output,'preview.js'),script);
  const css=await readFile(path.join(root,'public/styles.css'),'utf8');
  await writeFile(path.join(output,'styles.css'),css+'\n.access-status{margin:0;padding:12px 24px;background:#fff1d6;color:#493815;font:600 14px/1.5 system-ui}button:disabled{cursor:default;opacity:.6}\n');
  await copyFile(path.join(root,'public/favicon.svg'),path.join(output,'favicon.svg'));
  return {output,pages:Object.keys(pages)};
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  const result=await buildAccessPreview();
  console.log(`Built ${result.pages.length} sample-only pages in ${result.output}. No personal data or credentials included.`);
}
