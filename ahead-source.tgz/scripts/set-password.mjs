import {mkdir,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {makePasswordHash} from '../lib/auth.mjs';
if(!process.stdin.isTTY)throw new Error('Run this in your own terminal. Passphrases are entered privately, not as command arguments.');
async function hidden(prompt){
  process.stdout.write(prompt);process.stdin.setRawMode(true);process.stdin.setEncoding('utf8');process.stdin.resume();
  return new Promise((resolve,reject)=>{
    let value='';
    function finish(){process.stdin.setRawMode(false);process.stdin.pause();process.stdin.removeListener('data',read);process.stdout.write('\n');}
    function read(chunk){for(const char of chunk){if(char==='\u0003'){finish();reject(new Error('Cancelled.'));return;}if(char==='\r'||char==='\n'){finish();resolve(value);return;}if(char==='\u007f'||char==='\b'){value=value.slice(0,-1);continue;}if(char>=' '&&value.length<1024)value+=char;}}
    process.stdin.on('data',read);
  });
}
try{
  const password=await hidden('Choose your Ahead passphrase (14+ characters; input is hidden): ');
  const again=await hidden('Enter it again: ');
  if(password!==again)throw new Error('The passphrases did not match. Run the command again.');
  const hash=await makePasswordHash(password),directory=new URL('../data/',import.meta.url),file=new URL('owner-password-hash.txt',directory);
  await mkdir(directory,{recursive:true});await writeFile(file,hash+'\n',{mode:0o600});
  console.log('Saved the password hash to '+fileURLToPath(file));
  console.log('Copy that file’s single line into OWNER_PASSWORD_HASH in Render’s secret settings. Keep your chosen passphrase private.');
}catch(e){console.error(e.message);process.exitCode=1;}
