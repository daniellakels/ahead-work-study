// Render supplies its external HTTPS URL and listening port at runtime.
// Secrets stay in environment variables and are never printed.
const supplied=process.env.BASE_URL||process.env.RENDER_EXTERNAL_URL;
if(!supplied)throw new Error('Render must supply RENDER_EXTERNAL_URL, or set BASE_URL to the app’s HTTPS address.');
const origin=new URL(supplied);
if(origin.protocol!=='https:'||origin.username||origin.password||origin.search||origin.hash||origin.pathname!=='/')throw new Error('The deployed app address must be an HTTPS origin without a path or credentials.');
process.env.BASE_URL=origin.origin;
process.env.APP_ENV='production';
process.env.HOST='0.0.0.0';
if(!process.env.ENCRYPTION_KEY&&process.env.ENCRYPTION_KEY_BASE64){
  const encoded=process.env.ENCRYPTION_KEY_BASE64;
  if(!/^[A-Za-z0-9+/]{43}=$/.test(encoded))throw new Error('Render’s generated encryption key must contain 32 bytes encoded as base64.');
  const key=Buffer.from(encoded,'base64');
  if(key.length!==32)throw new Error('Invalid encryption key length.');
  process.env.ENCRYPTION_KEY=key.toString('hex');
}
await import('../server.mjs');
